function e(r){return new Worker(""+new URL("../workers/mainCanvas-DmGYsu2R.js",import.meta.url).href,{name:r==null?void 0:r.name})}export{e as default};
