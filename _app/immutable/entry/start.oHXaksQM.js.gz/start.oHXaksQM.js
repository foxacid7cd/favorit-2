import{f as a}from"../chunks/entry.BBFDhJct.js";export{a as start};
