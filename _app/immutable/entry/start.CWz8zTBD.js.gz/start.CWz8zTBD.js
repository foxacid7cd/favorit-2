import{h as a}from"../chunks/entry.DmdVAb75.js";export{a as start};
