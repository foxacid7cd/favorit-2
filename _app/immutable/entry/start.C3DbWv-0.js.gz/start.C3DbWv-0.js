import{f as a}from"../chunks/entry.DcWTuwT5.js";export{a as start};
