import{f as a}from"../chunks/entry.B5iMmGrF.js";export{a as start};
