import{e as a}from"../chunks/entry.B-_UO9gS.js";export{a as start};
