import{f as a}from"../chunks/entry.C9NybTgu.js";export{a as start};
