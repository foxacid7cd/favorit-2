import{h as a}from"../chunks/entry.CMWdxJ72.js";export{a as start};
