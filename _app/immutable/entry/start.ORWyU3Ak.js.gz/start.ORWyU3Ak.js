import{f as a}from"../chunks/entry.Bexdfa5x.js";export{a as start};
