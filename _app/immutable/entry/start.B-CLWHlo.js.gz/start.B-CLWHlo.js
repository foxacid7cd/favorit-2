import{h as a}from"../chunks/entry.nHNo6aSm.js";export{a as start};
