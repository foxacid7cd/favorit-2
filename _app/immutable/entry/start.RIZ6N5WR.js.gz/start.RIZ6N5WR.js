import{h as a}from"../chunks/entry.D230LJlc.js";export{a as start};
