import{f as a}from"../chunks/entry.BAFfoSHB.js";export{a as start};
