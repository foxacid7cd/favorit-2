import{f as a}from"../chunks/entry.BYJ_j390.js";export{a as start};
