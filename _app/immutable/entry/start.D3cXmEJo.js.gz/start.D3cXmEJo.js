import{e as a}from"../chunks/entry.Cw4iozXW.js";export{a as start};
