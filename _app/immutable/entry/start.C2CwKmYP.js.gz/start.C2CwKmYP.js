import{f as a}from"../chunks/entry.BW4XNL8d.js";export{a as start};
