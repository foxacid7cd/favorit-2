import{f as a}from"../chunks/entry.CfDxVM31.js";export{a as start};
