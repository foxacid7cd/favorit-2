import{e as a}from"../chunks/entry.s-dIhaQ3.js";export{a as start};
