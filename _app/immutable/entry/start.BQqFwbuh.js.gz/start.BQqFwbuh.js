import{e as a}from"../chunks/entry.CHLb9-d0.js";export{a as start};
