import{e as a}from"../chunks/entry.B21lV3fR.js";export{a as start};
