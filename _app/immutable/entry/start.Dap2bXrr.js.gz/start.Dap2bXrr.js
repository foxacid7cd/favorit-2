import{h as a}from"../chunks/entry.DzAKUcCh.js";export{a as start};
