import{e as a}from"../chunks/entry.B5PPTRlC.js";export{a as start};
