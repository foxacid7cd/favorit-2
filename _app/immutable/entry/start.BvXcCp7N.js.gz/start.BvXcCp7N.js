import{h as a}from"../chunks/entry.CjUBi28J.js";export{a as start};
