import{c as a}from"../chunks/entry.BpVsUC9m.js";export{a as start};
