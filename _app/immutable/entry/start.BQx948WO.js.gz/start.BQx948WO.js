import{h as a}from"../chunks/entry.D7Pda-8m.js";export{a as start};
