import{h as a}from"../chunks/entry.DmMfJ0aM.js";export{a as start};
