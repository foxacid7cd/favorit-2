import{c as a}from"../chunks/entry.CJATkVmx.js";export{a as start};
