import{h as a}from"../chunks/entry.C-06AV0P.js";export{a as start};
