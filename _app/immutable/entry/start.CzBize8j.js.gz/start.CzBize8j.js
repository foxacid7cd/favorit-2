import{e as a}from"../chunks/entry.AUaUpFBs.js";export{a as start};
