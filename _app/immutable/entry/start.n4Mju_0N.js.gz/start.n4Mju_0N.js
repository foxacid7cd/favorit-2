import{f as a}from"../chunks/entry.fuCHKyHA.js";export{a as start};
