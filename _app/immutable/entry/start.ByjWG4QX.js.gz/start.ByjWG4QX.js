import{e as a}from"../chunks/entry.BLTyz4rs.js";export{a as start};
