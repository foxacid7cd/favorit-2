import{h as a}from"../chunks/entry.BueS5Y_D.js";export{a as start};
