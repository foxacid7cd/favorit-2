import{f as a}from"../chunks/entry.CTCSQRgC.js";export{a as start};
