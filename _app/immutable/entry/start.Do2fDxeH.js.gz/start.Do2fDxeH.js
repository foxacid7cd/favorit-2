import{h as a}from"../chunks/entry.Ui-rux0l.js";export{a as start};
