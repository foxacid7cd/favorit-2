import{f as a}from"../chunks/entry.C3_XZyIm.js";export{a as start};
