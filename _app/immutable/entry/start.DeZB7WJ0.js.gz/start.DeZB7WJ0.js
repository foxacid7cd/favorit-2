import{f as a}from"../chunks/entry.B7OU6MT9.js";export{a as start};
