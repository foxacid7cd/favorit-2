import{h as a}from"../chunks/entry.Dntzv6iG.js";export{a as start};
