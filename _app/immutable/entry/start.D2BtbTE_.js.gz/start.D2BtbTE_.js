import{h as a}from"../chunks/entry.HneFuEes.js";export{a as start};
