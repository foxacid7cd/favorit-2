import{f as a}from"../chunks/entry.H6IJWFRx.js";export{a as start};
