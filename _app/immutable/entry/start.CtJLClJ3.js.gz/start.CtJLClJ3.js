import{h as a}from"../chunks/entry.V_S79XBC.js";export{a as start};
