import{f as a}from"../chunks/entry.Dx1eG8ca.js";export{a as start};
