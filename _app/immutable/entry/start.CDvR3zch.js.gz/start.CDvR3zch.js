import{f as a}from"../chunks/entry.B_vSSFQ6.js";export{a as start};
