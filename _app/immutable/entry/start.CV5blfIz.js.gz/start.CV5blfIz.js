import{f as a}from"../chunks/entry.BJoFVaLU.js";export{a as start};
