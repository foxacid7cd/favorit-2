import{e as a}from"../chunks/entry.Bn5U2ZZR.js";export{a as start};
