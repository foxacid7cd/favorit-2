import{f as a}from"../chunks/entry.D67g0HV8.js";export{a as start};
