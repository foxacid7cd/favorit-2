import{f as a}from"../chunks/entry.B2v5Tp8q.js";export{a as start};
