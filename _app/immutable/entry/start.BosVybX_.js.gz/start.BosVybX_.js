import{h as a}from"../chunks/entry.CY0GEfFi.js";export{a as start};
