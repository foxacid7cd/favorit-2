import{e as a}from"../chunks/entry.CsgzBmWf.js";export{a as start};
