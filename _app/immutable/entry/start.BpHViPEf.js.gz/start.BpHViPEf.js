import{f as a}from"../chunks/entry.OCQK6Y-T.js";export{a as start};
