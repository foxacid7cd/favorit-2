import{f as a}from"../chunks/entry.B85Yl8lb.js";export{a as start};
