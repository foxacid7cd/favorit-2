import{h as a}from"../chunks/entry.C4HVzuiw.js";export{a as start};
