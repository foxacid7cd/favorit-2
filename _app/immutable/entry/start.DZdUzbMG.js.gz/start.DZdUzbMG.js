import{h as a}from"../chunks/entry.On9P0-2T.js";export{a as start};
