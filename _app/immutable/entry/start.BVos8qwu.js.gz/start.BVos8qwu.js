import{f as a}from"../chunks/entry.BSR0axOo.js";export{a as start};
