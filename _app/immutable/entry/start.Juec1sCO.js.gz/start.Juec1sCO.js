import{e as a}from"../chunks/entry.LwN29kiV.js";export{a as start};
