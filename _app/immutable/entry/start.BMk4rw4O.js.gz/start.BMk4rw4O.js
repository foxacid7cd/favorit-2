import{f as a}from"../chunks/entry.in0k0Y2_.js";export{a as start};
