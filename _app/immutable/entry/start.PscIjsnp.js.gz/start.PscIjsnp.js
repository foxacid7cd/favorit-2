import{h as a}from"../chunks/entry.BcOGHxMb.js";export{a as start};
