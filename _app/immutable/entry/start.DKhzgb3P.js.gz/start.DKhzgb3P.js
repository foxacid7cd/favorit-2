import{f as a}from"../chunks/entry.DKlFVpmZ.js";export{a as start};
