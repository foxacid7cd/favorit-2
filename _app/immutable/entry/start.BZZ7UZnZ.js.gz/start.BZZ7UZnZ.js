import{c as a}from"../chunks/entry.B6KZ6T3w.js";export{a as start};
