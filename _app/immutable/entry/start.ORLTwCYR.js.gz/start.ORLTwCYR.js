import{h as a}from"../chunks/entry.DkjBQexa.js";export{a as start};
