import{f as a}from"../chunks/entry.BcpoYm6e.js";export{a as start};
