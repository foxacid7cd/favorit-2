import{h as a}from"../chunks/entry.nyvGSrKs.js";export{a as start};
