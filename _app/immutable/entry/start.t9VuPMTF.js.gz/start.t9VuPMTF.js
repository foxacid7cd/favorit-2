import{f as a}from"../chunks/entry.DGfQXuK-.js";export{a as start};
