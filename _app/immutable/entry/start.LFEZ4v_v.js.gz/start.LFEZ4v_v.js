import{f as a}from"../chunks/entry.dGA1uC8G.js";export{a as start};
