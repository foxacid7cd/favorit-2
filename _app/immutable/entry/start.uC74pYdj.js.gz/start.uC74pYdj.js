import{h as a}from"../chunks/entry.B-9ItLnJ.js";export{a as start};
