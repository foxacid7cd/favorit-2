import{h as a}from"../chunks/entry.J3yX9bNN.js";export{a as start};
