import{e as a}from"../chunks/entry.c0-HENLy.js";export{a as start};
