import{h as a}from"../chunks/entry.CMorR1vi.js";export{a as start};
