import{e as a}from"../chunks/entry.tpm-c7Mu.js";export{a as start};
