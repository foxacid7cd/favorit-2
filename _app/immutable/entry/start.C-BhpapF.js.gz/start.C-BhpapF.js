import{f as a}from"../chunks/entry.74ibBXYn.js";export{a as start};
