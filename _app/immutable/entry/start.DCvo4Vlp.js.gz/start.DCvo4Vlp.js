import{f as a}from"../chunks/entry.DnJGOsx5.js";export{a as start};
