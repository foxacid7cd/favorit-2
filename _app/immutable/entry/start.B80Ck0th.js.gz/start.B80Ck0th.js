import{h as a}from"../chunks/entry.DpBfPpGZ.js";export{a as start};
