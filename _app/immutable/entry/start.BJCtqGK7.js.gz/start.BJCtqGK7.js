import{f as a}from"../chunks/entry.Cgo8IBKd.js";export{a as start};
