import{h as a}from"../chunks/entry.XZnU14uJ.js";export{a as start};
