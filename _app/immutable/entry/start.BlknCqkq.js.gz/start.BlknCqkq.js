import{h as a}from"../chunks/entry.dJABlxYv.js";export{a as start};
