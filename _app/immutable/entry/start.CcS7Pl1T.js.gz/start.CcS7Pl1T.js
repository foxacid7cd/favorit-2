import{h as a}from"../chunks/entry.BS6TyaBX.js";export{a as start};
