import{f as a}from"../chunks/entry.YhTdg-9C.js";export{a as start};
