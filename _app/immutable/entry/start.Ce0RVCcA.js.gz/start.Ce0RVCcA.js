import{h as a}from"../chunks/entry.DJumqb8P.js";export{a as start};
