import{h as a}from"../chunks/entry.Cn9j16Ij.js";export{a as start};
