import{f as a}from"../chunks/entry.C-8eqr3t.js";export{a as start};
