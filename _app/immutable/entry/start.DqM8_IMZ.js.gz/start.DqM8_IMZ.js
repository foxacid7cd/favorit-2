import{h as a}from"../chunks/entry.DiYJZh6_.js";export{a as start};
