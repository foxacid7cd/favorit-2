import{f as a}from"../chunks/entry.DwakMfeZ.js";export{a as start};
