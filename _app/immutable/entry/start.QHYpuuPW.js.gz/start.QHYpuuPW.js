import{c as a}from"../chunks/entry.CM6NdZMF.js";export{a as start};
