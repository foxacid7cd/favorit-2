import{f as a}from"../chunks/entry.GWthWOFS.js";export{a as start};
