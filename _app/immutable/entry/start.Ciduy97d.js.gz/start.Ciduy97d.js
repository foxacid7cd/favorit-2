import{h as a}from"../chunks/entry.A0isWg1h.js";export{a as start};
