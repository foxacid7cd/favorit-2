import{e as a}from"../chunks/entry.D3xE68N6.js";export{a as start};
