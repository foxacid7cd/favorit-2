import{f as a}from"../chunks/entry.BNA6fD7f.js";export{a as start};
