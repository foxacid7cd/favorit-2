import{h as a}from"../chunks/entry.DmtyX_7L.js";export{a as start};
