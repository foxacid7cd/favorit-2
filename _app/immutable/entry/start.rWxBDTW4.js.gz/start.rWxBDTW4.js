import{h as a}from"../chunks/entry.D9AGYDmL.js";export{a as start};
