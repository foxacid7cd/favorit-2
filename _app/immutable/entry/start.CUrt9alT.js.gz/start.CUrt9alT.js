import{e as a}from"../chunks/entry.4uMnJblW.js";export{a as start};
