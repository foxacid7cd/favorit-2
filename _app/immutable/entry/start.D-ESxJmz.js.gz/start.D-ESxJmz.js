import{f as a}from"../chunks/entry.DxsN6LMg.js";export{a as start};
