import{e as a}from"../chunks/entry.CNeDXxL_.js";export{a as start};
