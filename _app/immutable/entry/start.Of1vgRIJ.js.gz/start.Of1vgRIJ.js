import{f as a}from"../chunks/entry.DpM0mRab.js";export{a as start};
