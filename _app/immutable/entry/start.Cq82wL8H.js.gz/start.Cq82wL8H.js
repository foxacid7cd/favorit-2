import{f as a}from"../chunks/entry.BM2zZGhz.js";export{a as start};
