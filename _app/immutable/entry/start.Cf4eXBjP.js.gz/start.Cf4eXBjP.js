import{h as a}from"../chunks/entry.E6u2PWUg.js";export{a as start};
