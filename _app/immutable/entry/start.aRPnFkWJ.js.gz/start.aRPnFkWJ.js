import{f as a}from"../chunks/entry.B_N4kNH1.js";export{a as start};
