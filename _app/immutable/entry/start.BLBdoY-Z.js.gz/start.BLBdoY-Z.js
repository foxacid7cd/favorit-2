import{f as a}from"../chunks/entry.B-TJt8a5.js";export{a as start};
