import{f as a}from"../chunks/entry.C7vumUp5.js";export{a as start};
