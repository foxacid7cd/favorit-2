import{h as a}from"../chunks/entry.B4wHVnFL.js";export{a as start};
