import{f as a}from"../chunks/entry.DoRX9rvx.js";export{a as start};
