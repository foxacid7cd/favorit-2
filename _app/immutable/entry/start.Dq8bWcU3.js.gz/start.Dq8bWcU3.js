import{f as a}from"../chunks/entry.BcRgFybZ.js";export{a as start};
