import{h as a}from"../chunks/entry.DzVreHkN.js";export{a as start};
