import{f as a}from"../chunks/entry.ZTb3m8Sz.js";export{a as start};
