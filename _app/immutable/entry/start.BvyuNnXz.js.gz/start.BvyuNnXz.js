import{f as a}from"../chunks/entry.D2vZS4pY.js";export{a as start};
