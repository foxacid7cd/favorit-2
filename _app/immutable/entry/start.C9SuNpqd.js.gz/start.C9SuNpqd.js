import{f as a}from"../chunks/entry.D7jez8Gl.js";export{a as start};
