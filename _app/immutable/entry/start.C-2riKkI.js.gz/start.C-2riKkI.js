import{h as a}from"../chunks/entry.DCsnxbgl.js";export{a as start};
