import{f as a}from"../chunks/entry.DYZCNHUZ.js";export{a as start};
