import{h as a}from"../chunks/entry.BrfxM6zV.js";export{a as start};
