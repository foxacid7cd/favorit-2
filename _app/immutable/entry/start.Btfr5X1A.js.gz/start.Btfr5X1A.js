import{e as a}from"../chunks/entry.CPkHa0fL.js";export{a as start};
