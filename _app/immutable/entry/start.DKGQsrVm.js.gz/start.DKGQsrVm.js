import{f as a}from"../chunks/entry.BcXfnkRC.js";export{a as start};
