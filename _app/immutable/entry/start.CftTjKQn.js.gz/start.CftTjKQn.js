import{f as a}from"../chunks/entry.jVED5teO.js";export{a as start};
