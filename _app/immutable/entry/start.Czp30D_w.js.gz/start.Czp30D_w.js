import{e as a}from"../chunks/entry.DBKuk-e0.js";export{a as start};
