import{f as a}from"../chunks/entry.yQTud9Qh.js";export{a as start};
