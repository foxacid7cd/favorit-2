import{f as a}from"../chunks/entry.u6Cz8Lcl.js";export{a as start};
