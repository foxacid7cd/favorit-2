import{h as a}from"../chunks/entry.DQ4-hr8r.js";export{a as start};
