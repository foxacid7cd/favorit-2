import{f as a}from"../chunks/entry.ChBKo-l4.js";export{a as start};
