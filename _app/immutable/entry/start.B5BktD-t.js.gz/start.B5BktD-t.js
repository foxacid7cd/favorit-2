import{h as a}from"../chunks/entry.Dp7rygR-.js";export{a as start};
