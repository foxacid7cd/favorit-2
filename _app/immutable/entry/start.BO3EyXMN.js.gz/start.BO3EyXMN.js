import{f as a}from"../chunks/entry.9jwt3RN2.js";export{a as start};
