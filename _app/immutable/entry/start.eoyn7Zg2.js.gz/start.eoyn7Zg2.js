import{f as a}from"../chunks/entry.3o25KoTK.js";export{a as start};
