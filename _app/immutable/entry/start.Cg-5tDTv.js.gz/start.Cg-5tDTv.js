import{f as a}from"../chunks/entry.CTazj5E6.js";export{a as start};
