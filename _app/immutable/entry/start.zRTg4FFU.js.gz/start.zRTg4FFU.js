import{f as a}from"../chunks/entry.GjNH2d4h.js";export{a as start};
