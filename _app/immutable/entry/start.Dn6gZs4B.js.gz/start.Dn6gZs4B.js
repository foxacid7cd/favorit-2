import{h as a}from"../chunks/entry.DJjBUYOR.js";export{a as start};
