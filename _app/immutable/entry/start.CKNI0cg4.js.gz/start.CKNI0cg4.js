import{f as a}from"../chunks/entry.DQBQ2Z3l.js";export{a as start};
