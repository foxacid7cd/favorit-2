import{f as a}from"../chunks/entry.Atzm7nC0.js";export{a as start};
