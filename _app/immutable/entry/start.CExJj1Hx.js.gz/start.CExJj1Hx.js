import{h as a}from"../chunks/entry.CZ-C72Uw.js";export{a as start};
