import{f as a}from"../chunks/entry.DX2qt0jO.js";export{a as start};
