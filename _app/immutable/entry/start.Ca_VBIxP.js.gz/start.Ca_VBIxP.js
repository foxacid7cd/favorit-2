import{f as a}from"../chunks/entry.AxdCYj8o.js";export{a as start};
