import{h as a}from"../chunks/entry.C-3sQQ-i.js";export{a as start};
