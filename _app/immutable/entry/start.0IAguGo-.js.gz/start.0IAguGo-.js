import{e as a}from"../chunks/entry.CEmcYRIu.js";export{a as start};
