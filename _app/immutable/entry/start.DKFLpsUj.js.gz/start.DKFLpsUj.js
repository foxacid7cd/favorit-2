import{f as a}from"../chunks/entry.CmLRBfkv.js";export{a as start};
