import{f as a}from"../chunks/entry.CmdwhN6v.js";export{a as start};
