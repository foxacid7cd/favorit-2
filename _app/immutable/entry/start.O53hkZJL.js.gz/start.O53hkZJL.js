import{e as a}from"../chunks/entry.BbgB5pdo.js";export{a as start};
