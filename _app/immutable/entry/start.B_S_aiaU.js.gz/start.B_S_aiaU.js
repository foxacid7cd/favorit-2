import{f as a}from"../chunks/entry.B-nCV094.js";export{a as start};
