import{h as a}from"../chunks/entry.DnQOKwSy.js";export{a as start};
