import{f as a}from"../chunks/entry.BodapiTa.js";export{a as start};
