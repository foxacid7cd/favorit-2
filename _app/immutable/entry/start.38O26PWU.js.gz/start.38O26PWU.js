import{e as a}from"../chunks/entry.B2Jk-7Tm.js";export{a as start};
