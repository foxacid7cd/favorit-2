import{h as a}from"../chunks/entry.CgfdB9Fo.js";export{a as start};
