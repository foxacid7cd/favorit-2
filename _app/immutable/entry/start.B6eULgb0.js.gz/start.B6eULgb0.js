import{f as a}from"../chunks/entry.BBXa7m4R.js";export{a as start};
