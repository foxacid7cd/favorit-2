import{e as a}from"../chunks/entry.CNdw8w7K.js";export{a as start};
