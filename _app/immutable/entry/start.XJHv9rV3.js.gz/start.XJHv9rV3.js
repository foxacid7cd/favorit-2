import{h as a}from"../chunks/entry.Dc0dEbQF.js";export{a as start};
