import{f as a}from"../chunks/entry.D2bgT5P4.js";export{a as start};
