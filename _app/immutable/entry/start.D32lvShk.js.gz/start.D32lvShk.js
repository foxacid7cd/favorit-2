import{f as a}from"../chunks/entry.CxKdtEWi.js";export{a as start};
