import{h as a}from"../chunks/entry.D9vpwGDF.js";export{a as start};
