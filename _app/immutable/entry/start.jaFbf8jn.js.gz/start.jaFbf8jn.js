import{f as a}from"../chunks/entry.B_6uW_-s.js";export{a as start};
