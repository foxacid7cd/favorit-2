import{f as a}from"../chunks/entry.B5NXYpyT.js";export{a as start};
