import{f as a}from"../chunks/entry.BiOltt-g.js";export{a as start};
