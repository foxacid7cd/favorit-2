import{f as a}from"../chunks/entry.C3VnDt4L.js";export{a as start};
