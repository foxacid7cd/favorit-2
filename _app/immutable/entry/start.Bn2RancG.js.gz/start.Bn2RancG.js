import{h as a}from"../chunks/entry.C9MTQ-_U.js";export{a as start};
