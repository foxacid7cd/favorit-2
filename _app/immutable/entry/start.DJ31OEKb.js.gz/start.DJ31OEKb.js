import{h as a}from"../chunks/entry.R7xk33Up.js";export{a as start};
