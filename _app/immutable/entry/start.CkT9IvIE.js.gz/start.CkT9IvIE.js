import{e as a}from"../chunks/entry.BtiNy36-.js";export{a as start};
