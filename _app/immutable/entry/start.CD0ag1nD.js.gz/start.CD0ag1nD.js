import{h as a}from"../chunks/entry.B9bZGxyp.js";export{a as start};
