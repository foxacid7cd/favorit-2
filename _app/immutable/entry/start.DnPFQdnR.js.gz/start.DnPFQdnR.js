import{h as a}from"../chunks/entry.B5C65Zbt.js";export{a as start};
