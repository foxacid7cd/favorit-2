import{f as a}from"../chunks/entry.CoS2KAwr.js";export{a as start};
