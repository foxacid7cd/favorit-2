import{h as a}from"../chunks/entry.4L1UKyQQ.js";export{a as start};
