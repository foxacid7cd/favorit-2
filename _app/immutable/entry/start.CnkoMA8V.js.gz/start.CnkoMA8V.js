import{f as a}from"../chunks/entry.DDW-OYt7.js";export{a as start};
