import{h as a}from"../chunks/entry.BVPCKpeg.js";export{a as start};
