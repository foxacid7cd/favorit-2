import{f as a}from"../chunks/entry.K7WqiO0c.js";export{a as start};
