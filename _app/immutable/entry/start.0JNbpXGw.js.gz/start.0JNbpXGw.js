import{f as a}from"../chunks/entry.QIoeMLuA.js";export{a as start};
