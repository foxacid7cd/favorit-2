import{h as a}from"../chunks/entry.BEshgoiX.js";export{a as start};
