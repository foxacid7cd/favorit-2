import{c as a}from"../chunks/entry.BOgs8T5P.js";export{a as start};
