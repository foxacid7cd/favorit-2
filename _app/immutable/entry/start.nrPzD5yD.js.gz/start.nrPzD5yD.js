import{f as a}from"../chunks/entry.L3d1_j3Y.js";export{a as start};
