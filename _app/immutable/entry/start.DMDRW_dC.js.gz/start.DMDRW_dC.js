import{f as a}from"../chunks/entry.BdzTkcnq.js";export{a as start};
