import{e as a}from"../chunks/entry.DcNe9EK_.js";export{a as start};
