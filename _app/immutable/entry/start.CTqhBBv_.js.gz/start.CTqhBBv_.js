import{h as a}from"../chunks/entry.CFMpfoSQ.js";export{a as start};
