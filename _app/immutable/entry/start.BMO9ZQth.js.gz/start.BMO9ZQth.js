import{e as a}from"../chunks/entry.CdRQJHq9.js";export{a as start};
