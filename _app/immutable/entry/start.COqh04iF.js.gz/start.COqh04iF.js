import{h as a}from"../chunks/entry.CBxWCcZL.js";export{a as start};
