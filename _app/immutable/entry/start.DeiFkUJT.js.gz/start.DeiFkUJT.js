import{h as a}from"../chunks/entry.BjGiPvaS.js";export{a as start};
